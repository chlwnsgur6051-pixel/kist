# Digit → letter heteroassociation (share package)

Self-contained PyTorch demos for sharing. **No HW-fit / synfit pipeline**, **T2 training only**.

| Track | Script | What it does |
|-------|--------|--------------|
| A | `contrastive_optimal_weight.py` | Theoretical optimal W via contrastive teacher + pinv |
| B | `stdp_t2_inhibition.py` | Spiking sim: STDP + US-off shunt (T2), CS-only recall |

## Layout

```
share_package/
  binary_character.py          # 5×3 digit / letter patterns
  contrastive_optimal_weight.py
  stdp_t2_inhibition.py
  model.py                     # LIF + step-conductance synapse + STDP
  training_protocols.py        # T2 spec + shunt helpers
  requirements.txt
  README.md
```

## Setup

```bash
cd share_package
pip install -r requirements.txt
# or: conda activate <env-with-torch>
```

## Track A — contrastive optimal weight

Target bits get teacher current `+I` / `-I`; solve `W, b = pinv([Φ, 1]) @ I_teacher`.  
Recall uses a simple LIF (not the conductance synapse model).

```bash
python contrastive_optimal_weight.py
python contrastive_optimal_weight.py --basis linear --run-name contrastive_linear
```

Edit `PARAMETER_SET` at the top of the script, or pass argparse flags.

## Track B — STDP T2 (nontarget inhibition)

**Training (T2):**

- CS pulse (digit) → CS→hidden synapses
- US-on: positive step on hidden where letter bit = 1
- US-off: negative shunt on hidden where letter bit = 0
- STDP updates conductance W

**Recall:** CS only, learned W (no US / no shunt).

Neuron and synapse parameters are hardcoded in `PARAMETER_SET` (no manifest JSON).

```bash
# quick smoke (2 pairs, short duration) — checks the pipeline only
python stdp_t2_inhibition.py --smoke

# full 10 pairs
python stdp_t2_inhibition.py --phase1-epochs 1 --initial-weight 50
```

Outputs under `results/stdp_t2_inhibition/<run_name>/` (`metrics.json`, `weights.npy`).

STDP hyperparameters in `PARAMETER_SET` are starting points; tune `--stdp-p`, `--stdp-d`, `--i-us-uA`, `--shunt-amp-uA` for better recall.

## Notes

- Humans: edit `PARAMETER_SET` in each entry script. Agents: prefer argparse.
- T0/T1/T3 and synfit fitting scripts are intentionally omitted.
- Default neuron/synapse numbers match a prior HW-inspired fit, but are inlined so this folder runs alone.
