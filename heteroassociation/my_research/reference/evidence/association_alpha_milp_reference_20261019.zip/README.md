# Association Learning Strength: Original MILP Reference Inputs

This pack contains the original **10 digit (0..9) -> 10 letter (A..J)** 15-bit bipolar vector dataset and alpha references used in the previous weighted correlation experiments.

## Files
- `dataset.npz`: `X_bipolar` and `Y_bipolar`, both `(10,15)` bipolar {-1,+1} arrays. Also includes derived `Gram`, `crosstalk`, `raw_scores`, `signed_margin` from the original archive. **Use the two original X/Y arrays as the authoritative source.** Rows correspond to digit 0 through 9, targets A through J.
- `optimized_alpha_reference.csv`: original K=10 MILP alpha and subsequent fixed-six margin-optimized alpha.
- `optimized_alpha_reference.npz`: same alpha reference vectors (`alpha_milp`, `alpha_margin_optimized`) and `recalled_digits` ([0,1,2,6,7,9]).
- `reproduce_K10_MILP.py`: minimal SciPy mixed-integer linear program that can find **an** optimum alpha (not necessarily the same vector). Uses no noisy cues.

## Baseline definitions
- `W = X.T @ (alpha[:, None] * Y)`.
- `prediction = np.where(X @ W > 0, 1, -1)`.
- Exact recall accuracy = percentage of association rows where **all 15 output bits** are correct.
- Uniform alpha=1 gives 10% (1/10) for K=10.
- Original target-informed MILP alpha gives 60% (6/10).
- Fixed-six margin-optimized alpha also gives 60% (6/10), with minimum signed output margin across the recalled six of about 1.389.
- MILP constraints: 0.01 <= alpha_p <= 4, sum(alpha)=10, threshold=0; maximize number of completely recalled associations.

## Notes for next experiments
Use this exact dataset and stored optimum as a historical **diagnostic reference**.
Re-run MILP only if needed. Because optimal alpha is not unique, do not assume the newly solved coefficients must match exactly; compare accuracy and margin too.
No noisy-cue tests. Do not edit the original STDP/LIF simulator. For K<10 use subsets of the same vectors.
The previous MILP has access to all target labels and is **not a local STDP learning rule**. Classify each candidate factor by whether it is available to local synapses, accessible through neuronal activities, or needs dataset-global information.
