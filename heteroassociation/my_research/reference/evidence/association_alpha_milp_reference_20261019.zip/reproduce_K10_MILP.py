#!/usr/bin/env python3
"""Reproduce the original K=10 association-weight MILP; original stored inputs only.
Requires NumPy + SciPy (scipy.optimize.milp). Do NOT run noisy-cue experiments.
"""
from pathlib import Path
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
ROOT=Path(__file__).resolve().parent
D=np.load(ROOT/'dataset.npz')
X,Y=D['X_bipolar'].astype(float),D['Y_bipolar'].astype(float)
K,OUT=Y.shape
G=X@X.T
# For each stored cue p and output j, signed margin = sum_q alpha_q * G[p,q] * Y[p,j]*Y[q,j]
C=np.einsum('pq,pj,qj->pjq',G,Y,Y).reshape(K*OUT,K)
# Binary z_p equals 1 only if all its output bit constraints are satisfied.
Z=np.repeat(np.eye(K),OUT,axis=0)
M=1000.
rows=np.column_stack([-C,M*Z])
cons=[LinearConstraint(rows,lb=np.full(K*OUT,-np.inf),ub=np.full(K*OUT,M-1e-4)),
      LinearConstraint(np.r_[np.ones(K),np.zeros(K)][None,:],lb=K,ub=K)]
obj=np.r_[np.zeros(K),-np.ones(K)]
lower=np.r_[np.full(K,.01),np.zeros(K)]
upper=np.r_[np.full(K,4.),np.ones(K)]
result=milp(obj,integrality=np.r_[np.zeros(K),np.ones(K)],
            bounds=Bounds(lower,upper),constraints=cons,
            options={'mip_rel_gap':0.001,'time_limit':120.})
if result.x is None:raise RuntimeError(result.message)
alpha=result.x[:K]
W=X.T@(alpha[:,None]*Y)
score=X@W
pred=np.where(score>0,1,-1)
correct=np.all(pred==Y,axis=1)
print('MILP status:',result.message)
print('Alpha:',alpha)
print('Exact accuracy:',correct.mean())
print('Recalled digits:',np.flatnonzero(correct).tolist())
print('Note: optimal alpha vectors are not unique. Reproduced optimum may differ from saved alpha.')
